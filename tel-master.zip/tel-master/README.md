# Internet Gratis

Aceh Cyber Team


Requirements
------------

    Git
    Python27


Usage
-----

    $ git clone https://github.com/Ro0TN3T/tel.git
    $ cd tel
    $ chmod +x tel.py
    $ python2 tel.py


Updating
--------

    $ cd tel
    $ git pull
    $ python2 tel.py


Contact
-------

Facebook Group : [Aceh Cyber Team]

